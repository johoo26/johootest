name = "Hu Shiyu"
gender = "Male"
location = "Shen Zhen"
